const Crew = () => {
  return (
    <div>Crew</div>
  )
}

export default Crew