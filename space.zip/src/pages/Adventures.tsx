const Adventures = () => {
  return (
    <div>Adventures</div>
  )
}

export default Adventures